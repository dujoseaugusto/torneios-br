﻿ <ul class="nav" id="main-menu">
		<li class="text-center"><img src="../images/logotipo.jpg" class="user-image img-responsive"/></li>
				                    
    <li>
      <a href='list_usuarios.php'><i class="fa fa-desktop fa-3x"></i>Lista de usuários</a> 
       
    </li>
     <li>
        <a href="#"><i class="fa fa-sitemap fa-3x"></i> Cadastros<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
            <li><a href='cad_modalidade.php'>Modalidade</a></li>
            <li><a href='cad_temporada.php'>Temporadas</a></li>
            <li><a href='cad_etapa.php'>Etapas</a></li>
            <li><a href='cad_pontuacao.php'>Pontuação</a></li>
            <li><a href='cad_club.php'>Clubes</a></li>
            <li><a href='cad_banner.php'>Banner Inicial</a></li>
            <li><a href="cad_gal_fotos.php">Galeria de Fotos</a></li>
        </ul>
      </li> 
    
    <li>
        <a href="#"><i class="fa fa-edit fa-3x"></i> Incrições<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
            <li><a href='ver_etapa.php'>Ver inscritos nas etapas</a></li>
            <li><a href='ver_etapa_fech.php'>Etapas Fechadas/Reabrir</a></li>
        </ul>
    </li>
    
    <li><a href='upload.php'><i class="fa fa-download fa-3x"></i>Arquivo de baixa</a></li>

    <li>
        <a href="#"><i class="fa fa-cog fa-3x"></i> Logs/Backups<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
            <li><a href='log.php'>log de acesso</a></li>
            <li><a href='Backup.php'>Backup</a></li>
        </ul>
    </li> 

     <li>
        <a href="#"><i class="fa fa-table fa-3x"></i> Not&iacute;cia<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
            <li><a href='CadastraNoticias.php'>Cadastro</a></li>
            <li><a href='AlterarNoticia.php'>Alterar</a></li>
        </ul>
    </li>
    <li><a href='AlteraRodape.php'><i class="fa fa-square-o fa-3x"></i>Roda Pé</a></li>  

   <li><a href='cad_anuncios.php'><i class="fa fa-square-o fa-3x"></i>Anunciantes</a></li>	
   
   <li><a href='cad_calendario.php'><i class="fa fa-square-o fa-3x"></i>Calendário</a></li>
  
   <li><a href='cad_videos.php'><i class="fa fa-square-o fa-3x"></i>Vídeos</a></li>				
				                    
</ul>